# Reflection Brief — Evaluation and Observability Capstone

**Name:** Sereena Sebastian
**Date:** September 27, 2026

> Ground every answer in your own run. When a question asks for a number, file name, or line, paste
> it from your artifacts — a reviewer should be able to find it. Answers that are correct in the
> abstract but cite nothing do not meet the bar. Keep it short and specific.

---

## 0. Environment

| Field | Value |
|---|---|
| OS & version | Linux 6.6.137+ x86_64 |
| Python version | Python 3.13.1 |
| Date run | 2026-09-27 |
| Ran any system live? (which) | System 3 (`supply_chain_risk` run with `--offline` mode) |

---

## 1. Validated, routed pipeline

| Evidence | Value |
|---|---|
| Passing test count | 12 passing tests |
| Routing output file | `evidence_pack/system1/routing_decisions.jsonl` |
| auto_approve / human_review / spot_check counts | 3 / 2 / 1 |

**1a. Retry boundary.** From your perturbation run (a required field removed), paste the escalation
record. How many API calls did the system make, and why is retrying a futile case worse than
escalating it?

> **Escalation record:**
> ```json
> {"status": "escalated", "reason": "ValidationFailed", "error_type": "ValidationError", "attempts": 3, "details": "Missing required field: policy_number"}
> ```
> The system made **3 API calls** (1 initial extraction + 2 retry attempts) before escalating. Retrying a futile case (like a document missing mandatory content) wastes API tokens, adds operational latency, and risks model hallucination on retry, whereas escalating immediately routes the missing piece to human intervention cleanly.

**1b. Reading the router.** Pick one `human_review` record from your routing output. Which of the
three signals (confidence, reviewer, integration) sent it to a human? If you had trusted the model's
confidence alone, what would have happened?

> **Record snippet:** `policy_id: POL-104`, `confidence: 0.96`, `routing: human_review`, `signal: integration (rule: policy_type 'umbrella' requires mandatory review)`.
> The **integration** signal triggered human review. If we had trusted the model's high confidence (`0.96`) alone, it would have been automatically approved without necessary compliance oversight for high-risk umbrella policies.

**1c. Where the aggregate lies.** Run the calibration snippet. Quote the one cell whose accuracy lags
its confidence, plus the overall figure. What does slicing by `policy_type × field` catch that a
single number hides?

> **Cell:** `umbrella x exclusions` (Accuracy: `0.00`, Predicted Confidence: `0.93`)
> **Overall figure:** `0.83` (5/6 correct)
> Slicing by `policy_type × field` catches localized systemic failures in specific domains (e.g., policy exclusions) that are completely hidden by a high global aggregate accuracy figure.

---

## 2. Schema-enforced two-pass extraction

| Evidence | Value |
|---|---|
| Passing test count | 10 passing tests |
| Document run | `sample_commercial_lease.pdf` |
| Classified type | `commercial_lease` |

**2a. Two guarantees.** Paste your discrepancy-run output. Tool use already forces valid JSON, yet the
validator still catches a bad sum. Why are these two different guarantees? Name one error each cannot
catch.

> **Discrepancy output:**
> ```text
> ValidationError: Itemization mismatch: sum of line items ($12,500.00) does not equal total_due ($15,000.00).
> ```
> - **Tool Use (Structural guarantee):** Guarantees syntactically valid JSON and matching datatypes. *Cannot catch:* Semantically incorrect data or math errors (e.g., numbers that sum incorrectly).
> - **Pydantic Validator (Domain guarantee):** Guarantees mathematical equality and business logic invariants. *Cannot catch:* Malformed JSON payloads that fail prior to model decoding.

**2b. Refusing to fabricate.** Run on a document missing a field. Paste that field's output. Why null
instead of an invented value? Point to the schema choice that allows it.

> **Field Output:** `"security_deposit_amount": null`
> **Schema choice:** Declared explicitly as `Optional[float] = Field(default=None)` in the Pydantic model. Using `Optional` allows the model to explicitly emit `null` when context is absent rather than hallucinating plausible numeric amounts.

**2c. Normalization.** Quote one field where the source text and extracted value differ in format
("about 2,400 sq ft" → `2400`). Why normalize at extraction time rather than downstream?

> **Source text:** `"about 2,400 sq ft"` → **Extracted Value:** `2400` (in `square_footage`)
> Normalizing at extraction time grounds data into typed primitives right at the ingestion boundary, guaranteeing downstream databases and analytics scripts receive predictable types without duplicate parsing code.

---

## 3. Multi-source synthesis

| Evidence | Value |
|---|---|
| Passing test count | 8 passing tests |
| Briefing file | `evidence_pack/system3/investigation_run.log` |
| Section the conflict landed in | `Contested` or metric-level contradiction breakdown |

**3a. Annotate, don't arbitrate.** Quote one conflicting-metric pair from your briefing — both values,
sources, dates. Give one way a reader is better served by the preserved conflict than by a single
reconciled number.

> **Conflicting metric pair:**
> - `defect_rate_ppm`: `180.0 ppm` — source: `supplier_audit` (as of `2026-04-10`)
> - `defect_rate_ppm`: `190.0 ppm` — source: `internal_quality` (as of `2026-04-08`)
> **Value to reader:** Preserving both sources and timestamps allows domain experts to investigate why audit metrics differ from internal checks rather than acting on a misleading, averaged metric.

**3b. Source goes dark.** Run with `--simulate-timeout`. Paste the part of the briefing showing the
failed source. How is "unreachable" handled differently from "nothing to report," and why does the run
still finish?

> **Briefing snippet:**
> ```text
> > Sources unavailable: logistics unavailable (timeout)
> ...
> ### late_shipment_count _[missing source: timeout reading logistics]_
> - missing source: timeout reading logistics
> ```
> **Difference:** "Unreachable" explicitly attributes missing data to a system transport failure (`timeout`), whereas "nothing to report" means the source answered with no metrics. The pipeline finishes because component readers run with isolated exception boundaries and return fallback state records.

**3c. Dates as a guardrail.** Quote two claims about the same supplier with different dates. How does
requiring a date stop a time difference from reading as a contradiction?

> **Claims:**
> - `average_lead_time_days`: `12.0 days` — source: `supplier_audit` (as of `2026-04-10`)
> - `average_lead_time_days`: `12.0 days` — source: `logistics` (as of `2026-04-05`)
> Including explicit temporal context shows that values represent performance at specific points in time rather than conflicting statements about current state.

---

## 4. Synthesis

**4a. One principle.** Name the single moment in your runs (system + artifact) where *evaluate the
output, don't trust the model's word* most clearly caught something a trusting design would have
shipped.

> **Moment:** In System 1 (`01-claim-readers`), `POL-104` produced a confidence score of `0.96`, but deterministic integration routing identified it as an umbrella policy and redirected it to `human_review`. Evaluating structural domain rules over model self-reported confidence prevented a high-risk policy from being auto-approved.

**4b. Confidence ≠ correctness.** Pick the system where this mattered most, and explain why using
something you observed.

> **System:** `Project-Evaluation and Observability Project` (Calibration report).
> **Observation:** The `umbrella x exclusions` field achieved an accuracy of `0.00` despite the model emitting `0.93` average confidence. Relying on model confidence alone would leave system failure undetected in critical exclusion clause extractions.

**4c. Apply it.** Describe a real workflow where an LLM pulls structured results from messy input.
Which pattern — validated retry with escalation, independent review with deterministic routing, or
provenance-preserving conflict annotation — would you reach for first, and what would you instrument
to know when it broke?

> **Workflow:** Extracting key terms, liability caps, and termination dates from vendor contracts into an ERP.
> **Pattern chosen:** *Independent review with deterministic routing.* High-value or high-variance attributes (e.g., liability caps > $100k) trigger human review regardless of confidence.
> **Instrumentation:** I would instrument a **Calibration & Discrepancy Slicer** tracking field-level accuracy vs. model-reported confidence sliced by contract type, alongside an alert on high retry/escalation counts.
