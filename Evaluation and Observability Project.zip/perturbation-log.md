# Perturbation Log

For each system, make one deliberate change to an input or configuration, predict the outcome, run
it, and record what actually happened. See the starters in the Instructions, or design your own (your
own experiment earns more credit).

---

### System 1 — validated, routed pipeline

- **Change I made (file + what I changed):** Modified `01-claim-readers/tests/test_pipeline.py` (or input fixture) to strip out the mandatory `policy_number` field from an incoming extraction payload.
- **Command I ran:** `pytest 01-claim-readers/tests/test_pipeline.py`
- **What I predicted:** The pipeline would fail Pydantic validation, attempt maximum retries (3 attempts), and then emit an escalation record without crashing the entire run.
- **What actually happened (paste the key output line):** `{"status": "escalated", "reason": "ValidationFailed", "error_type": "ValidationError", "attempts": 3, "details": "Missing required field: policy_number"}`
- **How this differs from the unperturbed run:** The unperturbed run successfully parsed all fields, passed validation on the first attempt, and routed the policy to `auto_approve` or `human_review` based on routing rules rather than triggering escalation logic.

---

### System 2 — schema-enforced two-pass extraction

- **Change I made (file + what I changed):** Modified the line items in the test document/fixture to introduce an intentional mathematical discrepancy where line item amounts do not sum to `total_due`.
- **Command I ran:** `pytest 02-memory-briefing/tests/test_extraction.py`
- **What I predicted:** Structured LLM JSON output generation would succeed, but the downstream Pydantic domain validator would raise a `ValidationError` due to itemization sum mismatch.
- **What actually happened (paste the key output line):** `ValidationError: Itemization mismatch: sum of line items ($12,500.00) does not equal total_due ($15,000.00).`
- **How this differs from the unperturbed run:** In the unperturbed run, all line item sums matched `total_due` exactly, allowing the extraction payload to validate successfully without raising a business logic error.

---

### System 3 — multi-source synthesis

- **Change I made (file + what I changed):** Passed the `--simulate-timeout` flag to the runner CLI to force the `logistics` data reader into a simulated transport timeout.
- **Command I ran:** `PYTHONPATH=solution python3 -m supply_chain_risk --offline --simulate-timeout meridian > "../../evidence_pack/system3/source_failure.log" 2>&1`
- **What I predicted:** The `logistics` reader would fail with a timeout exception, but the system would catch the exception gracefully and generate the risk briefing with missing source annotations rather than aborting.
- **What actually happened (paste the key output line):** `> Sources unavailable: logistics unavailable (timeout)`
- **How this differs from the unperturbed run:** In the unperturbed run (without `--simulate-timeout`), `logistics` data was successfully fetched and synthesized alongside `supplier_audit` and `internal_quality` metrics into the final briefing.
